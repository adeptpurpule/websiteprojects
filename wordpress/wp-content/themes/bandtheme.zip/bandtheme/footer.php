<?php
?> 
<div class="row">
        <div class="twelve columns">
          <ul id="menu3" class="footer_menu horizontal">
            <li class=""><a href="index.html">Home</a></li>
        </div>
      </div>