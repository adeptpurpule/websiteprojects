<?php
?>
<head>
     <link rel="stylesheet" type="text/css" href="css/stylesheet.css">
       <link rel="stylesheet" type="text/css" href="css/app.css">
         <link rel="stylesheet" type="text/css" href="css/foundation.css">
           <link rel="stylesheet" type="text/css" href="css/foundation.min.css">
           <link rel="stylesheet" type="text/css" href="css/stylesheet.css">
            <link rel="stylesheet" type="text/css" href="css/main.css">
              <link rel="stylesheet" type="text/css" href="css/flexmenu.css">
              <link rel="script" href="js/menu.js"/>
             
 </head>
 <body>
     <div id="wrapper">
       <div id="bannerhead"><img src="images/banfinal.png" ></img></div>
      <nav class="menu">
       
  <ul>
    <li><a href="#">Home</a></li>
    <li class="sub-menu"><a href="#">About</a>
      
      <ul>
          <li><a href="#">History</a></li>
          <li><a href="#">Bio</a></li>
      </ul>
    
    </li>    
    <li><a href="#">Work</a></li>
    <li><a href="#">Contact</a></li>
  </ul>
</nav><!--/menu-->